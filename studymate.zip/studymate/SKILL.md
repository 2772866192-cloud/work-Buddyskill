---
name: studymate
description: StudyMate 学习系统（移植自 github.com/Miaotofu01/Study-Mate）。当用户想系统学一门科目、制定按前置依赖排布的学习路线、设计课件与分层练习、安排实操/实验任务、验收学习成果，或要「继续上次学到哪」「换一门课接着学」时，应使用本 skill。它维护一个独立的学习工作区（共享记忆 + 科目档案 + 课程大纲 + 三档进度 + 误解库），把资料收集、课程设计、讲解、出题评估派给独立子代理，并把课件渲染成可离线阅读的 HTML。不适用于一次性的知识问答或单篇文档撰写。
agent_created: true
---

# StudyMate 学习系统（WorkBuddy 移植版）

## 先读这一段

本 skill 移植自 StudyMate v2.0.3（`d8114f3`，MIT）。原项目是 DSH / Antigravity / Codex 的**原生插件**：阅读端、`studymate_*` 原生工具、预设档位都长在宿主里，WorkBuddy 没有这些。

因此本 skill 装的是**方法论 + 工作流 + 数据格式**，不是宿主插件本体：

- `references/` 保留了 12 份角色/协议规范与 5 份格式规范的**原文**，是判据的唯一出处；正文里出现的 `<root>` 一律指原仓库根，按下方对照表换算成本 skill 的文件。
- 原文里的 `studymate_*` 工具调用、`ask_user_question`、`subagent`、`阅读端`，**一律按下方「适配映射」翻译后再执行**；不要尝试调用这些不存在的工具，也不要因为找不到而改写规范本身。
- 角色文件 frontmatter 的 `disable-model-invocation: true` 在 WorkBuddy 里没有对应机制：这些文件只作为参考文档，由总控派子代理时显式读取，不会自动触发。

`<SKILL>` = `C:/Users/27728/.workbuddy/skills/studymate`（迁移到别的机器时替换这一段）。
`<WS>` = 学习工作区，默认 `~/StudyMate`，用户指定过就用用户的。
`<SUB>` = `<WS>/.learning/subjects/<slug>`。
下文命令用 `python`，Windows / macOS / Linux 通用；Python ≥ 3.9，只用标准库。

## 包内布局与原文路径对照

WorkBuddy 的 skill 包只允许**两级目录**：根目录下只有 `references/`、`assets/`、`scripts/` 三个子目录，所有文件直接放在其中，**没有更深的目录**。原仓库的嵌套路径按这张表编码成扁平文件名：

| 原仓库路径 | 本 skill 里的文件 |
|---|---|
| `preset/skills/<name>/SKILL.md` | `references/role__<name>.md` |
| `docs/规范/<name>.md` | `references/spec__<name>.md` |
| `templates/<a>/<b>/<file>` | `assets/tpl__<a>__<b>__<file>`（`__` 代表一级 `/`） |
| `schemas/<name>.json` | `assets/schema__<name>.json` |

规范原文**一字未改**，所以读原文时遇到：`<root>/docs/规范/文件归属.md` → 读 `references/spec__文件归属.md`；`<root>/preset/skills/learning-coach/SKILL.md` → 读 `references/role__learning-coach.md`；`<root>/templates/lab/` → 读 `assets/tpl__lab__*`。**不要去 skill 目录里找 `docs/`、`preset/`、`templates/` 这些目录**。需要把模板还原成目录树时跑 `restore_templates.py`。

## 资源索引（按需读，别一次全读进上下文）

| 路径 | 内容 | 什么时候读 |
|---|---|---|
| `references/role__learning-system.md` | 总控原文：开场、盘问、学习循环、派发规范 | 第一次接手学习任务时 |
| `references/role__record-keeping.md` | 档案维护：记忆、进度、误解、学习记录 | 写任何状态文件前 |
| `references/role__lesson-design.md`、`role__layered-practice.md` | 课件内核、四层题目与题型规范 | 派讲解／出题角色前 |
| `references/role__{resource-scout,image-scout,curriculum-designer,learning-coach,practice-evaluator}.md` | 五个角色规格 | 派该角色时，把绝对路径写进子代理 prompt |
| `references/role__{learning-discovery,local-qa,evidence-check}.md` | 方向探索、就地答疑、实验验收协议 | 对应情境发生时 |
| `references/spec__文件归属.md` | **代称 ↔ 真实路径 ↔ 维护者**的唯一出处 | 不确定某份文件叫什么、归谁写时 |
| `references/spec__课件内容格式.md` | `:::` 指令、块语法、题库锚点、反例 | 写或校验课件时 |
| `references/spec__Agent交接协议.md` | 暂存交付的机器边界 | 搬 `deliver/` 产物前 |
| `references/使用说明-原版.md`、`安装-*.md` | 原宿主的安装与日常使用方式 | 只需理解原设计意图时 |
| `assets/tpl__*`、`assets/schema__*.json` | 工作区骨架与 9 份 JSON Schema | 初始化、写结构化文件时 |

## 适配映射（关键，逐条照做）

| 原文里的 | WorkBuddy 里改成 |
|---|---|
| `studymate_workspace_context` | `python <SKILL>/scripts/validate.py workspace <WS>`，读它打印的 JSON 摘要；开场只跑这一次 |
| `studymate_validate_curriculum` | `python <SKILL>/scripts/validate.py curriculum <SUB>/curriculum.yaml` |
| `studymate_validate_lesson` | `python <SKILL>/scripts/validate.py lesson <SUB>/lessons/<课件>.md` |
| `studymate_validate_handoff` | `python <SKILL>/scripts/validate.py handoff <deliver目录> <SUB>`；通过后加 `--apply` 原样搬入，再清掉本轮 `.stage/` |
| `studymate_validate_pool` | 人工核对 `<SUB>/assets/img/pool.md` 七列表头与图片文件是否都在；不要求逐字节复算 |
| `studymate_apply_empty_reasons` | 用 Edit 在对应 `::: quiz` 块内补一行 `empty_reason: <出题人给的理由>`，别改别处 |
| `studymate_verify_sources` | 用 WebSearch / WebFetch 逐条打开「资源清单」里的链接核对可达性 |
| `studymate_lab_run` | 用 Bash 跑 `lab/<NNNN>-主题/check.sh`，**只如实转述**退出码、stdout、stderr，不自己下通过判决 |
| `studymate_renumber_lessons` | 大纲插/删节点后，把 `lessons/` 下文件名前缀按大纲顺序重排成 4 位补零，同步 `.quiz.json`、`attempts/` 与课件里的 `related` 条目 |
| `studymate_export` / 阅读端 | `python <SKILL>/scripts/render_lesson.py --subject <SUB>`，产物在 `<WS>/export/`，再用 present_files 打开 `index.html` |
| 阅读端答题面板、作答数据 | 没有阅读端：学生把答案贴回对话，按 `evidence-check` 验收；**不写 `attempts/`、绝不写回题库** |
| `ask_user_question` | AskUserQuestion 工具；一次问一张卡片，推荐项放第一并标「(Recommended)」 |
| `subagent` / `skill` 工具 | Agent 工具（全新上下文），prompt 里给角色规格的绝对路径，明说「先读它、照它执行」 |
| `studymate_task_wait` 等任务工具 | 不轮询、不 sleep；一轮发多个独立工具调用，有依赖就串行 |

## 工作区与代称速查

| 代称 | 路径 |
|---|---|
| 共享记忆 | `<WS>/.learning/MEMORY.yaml` |
| 科目记忆 | `<SUB>/MEMORY.yaml` |
| 科目使命 / 资源清单 / 术语表 | `<SUB>/MISSION.md` / `RESOURCES.md` / `GLOSSARY.md` |
| 科目档案 / 课程大纲 / 学习进度 / 误解库 | `<SUB>/subject.yaml` / `curriculum.yaml` / `progress.yaml` / `misconceptions.yaml` |
| 课件内容文件 / 练习题库 | `<SUB>/lessons/<NNNN>-<节点id>.md` / `.quiz.json` |
| 实操任务 / 参考解 | `<SUB>/lab/<NNNN>-主题/` / `lab/solutions/` |
| 图片库 / 索引 | `<SUB>/assets/img/pool/` / `pool.md` |
| 学习记录 | `<SUB>/learning-records/NNNN-*.md` |

首次使用先初始化（**只在缺失时复制，不覆盖已有记忆**）：

```sh
python <SKILL>/scripts/init_workspace.py --workspace <WS>
python <SKILL>/scripts/init_workspace.py --workspace <WS> --subject <slug> --name "<科目名>" --goal "<一句话目标>"
python <SKILL>/scripts/restore_templates.py --out <WS>/templates              # 要看完整模板树时
python <SKILL>/scripts/restore_templates.py --out <SUB>/lab --lab-only       # 造实操/实验课时照抄骨架
```

`lab/`、`sources/` 刻意不预建；`assets/tpl__lab__*` 是造实验课时照抄的骨架，用上面第四条命令还原成目录树。

## 工作流（总控，唯一有用户通道的角色）

1. **开场**：跑一次 `validate.py workspace <WS>` 拿摘要；`ready` 信息缺失就如实说明并停。加载 `references/role__record-keeping.md` 按需读恢复视图。把科目清单摆给用户，报上次学到哪、建议学什么，最后一行给「**下一步**：… —— 怎么触发」。
2. **方向探索 / 盘问**：用户没定科目时读 `role__learning-discovery.md` 亲自访谈；用户报了新科目时按 `role__learning-system.md` 的「新科目盘问」分轮问目的、深度、前置基础（学生自评，必问）、配套项目、实验课载体。已记在共享记忆里的事实不重复问。盘完再建课。
3. **建科目**：跑 `init_workspace.py --subject`；写「科目使命」（`## Why` / `## Success looks like` / `## Constraints` / `## Out of scope`）、术语表 `## 待掌握`。
4. **资料与大纲**：派 `resource-scout`（先问用户本地资料路径）产出「资源清单」；并行派 `image-scout` 与 `curriculum-designer`；自己写 `curriculum.yaml`、`progress.yaml`，用 `validate.py curriculum` 过一遍。图片库为空不阻塞。
5. **学习循环（一个节点）**：
   - 概念课/实操课**串行两段**：先派 `learning-coach` 写课件内容文件，内容落盘后再派 `practice-evaluator` 出题；实验课不派讲解，一次出说明页 + 实验任务。
   - 长产出让角色按最终相对路径落到 `<SUB>/.stage/<角色>-<节点>/deliver/`，先跑 `validate.py handoff`，通过才 `--apply` 搬入；**题面与答案一个字不改**，搬完清掉本轮 `.stage/`。
   - 跑 `validate.py lesson` 校验；报了 `文件:行` 就按归属打回原角色改，别代改。
   - 跑 `render_lesson.py --subject <SUB>` 生成课件页面，告诉用户打开 `<WS>/export/index.html`。
   - 学生说「学完了」才在 `kind: 实验` 的节点派验收；通过则把该节点与其 `prerequisites` 都置为「已学完」并写一条学习记录。
   - 卡住就派讲解换讲法；连续两次无效把练习降一档。
6. **档案**：进度三档只写 `progress.yaml`，且**只写有变化的节点**；误解只写 `misconceptions.yaml`；学习记录**有可观察证据才写**；两份记忆在对应节末尾追加一行（值以 `*`/`&`/`!` 开头要加引号），不整份改写。
7. **收尾**：每轮回复最后一行都写 `**下一步**：<谁做什么> —— <怎么触发>`；用户说「今天到这」就简短收尾，别再推。

## 派子代理的硬约束

- **只派五类活**：收集资料、采图、拟大纲、写课件内容、出题与验收。答疑、盘问、元数据、档案、写盘、校验一律自己做。判断标准：这件事需要外部检索／大量生成／独立验证吗？
- prompt 只写三样：① 角色规格的**绝对路径** + 「先读它、照它执行」；② 按该规格「输入」节给值（路径、节点 id、载体等）；③ 三条边界（不派下级子 agent、不调用 AskUserQuestion、产物按归属落 `deliver/`）。**不复述要求、不复述格式、不贴全文**。
- 上游产物给**绝对路径 + 节点 id** 让下游自己读，不转述内容。锚点文本是课件与题库的唯一接头，**只按锚点逐字对账，不按序号**。
- 验收不过把**原始错误**打回同一个角色自己改，不另派新代理、不代改；交付前 `.stage/` 必须为空。
- 同一科目同时只允许一个写入者；并行只给「不写同一份文件」的两支。

## 内容格式要点（完整判据在 `references/spec__课件内容格式.md`）

- 课件 front matter 只有 `title` 与 `goal`；`title` 必须与大纲该节点逐字一致；文件名序号 = 节点在大纲里的位次（4 位补零）。
- 正文**一个 HTML 标签都不写**；块组件用 `:::`，每个块单独一行 `:::` 收尾。只支持 `##` / `###`，代码块用围栏。
- 题目位置写 `::: quiz <层级> 锚点：<锚点文本>`；题库是 `{"锚点文本": [题, ...]}`。四种题型：客观题（`opts`/`ans`/`why`）、预测验证（`预测`/`比对`）、开放题（`answer`/`criteria`）、交付物（`交付物`/`证据`/`criteria`）；**每道题都必须有 `q`**。无题的锚点补 `empty_reason:`。
- 配图从 `assets/img/pool/` 取，逐字写 `../assets/img/pool/<文件>`，`alt:` 必填；自产 SVG 走 `::: svg`。

## 脚本速查

```sh
python <SKILL>/scripts/validate.py workspace  <WS>
python <SKILL>/scripts/validate.py curriculum <SUB>/curriculum.yaml
python <SKILL>/scripts/validate.py lesson     <SUB>/lessons/0001-intro.md
python <SKILL>/scripts/validate.py handoff    <SUB>/.stage/learning-coach-intro/deliver <SUB> --apply
python <SKILL>/scripts/render_lesson.py --subject <SUB>
python <SKILL>/scripts/restore_templates.py --out <SUB>/lab --lab-only
```

校验器输出 `[阻断]` / `[提示]` 逐条问题，退出码 1 表示有阻断项；**以它报的 `文件:行号` 为准改，别自己复算一遍**。

## 边界

- 学习文件只写 `<WS>` 下，绝不写会话目录；`assets/` 与 `references/` 只读。
- 不改「练习题库」里的学生作答，不把学习数据写进别的科目；跨科目只共享 `.learning/MEMORY.yaml`。
- 原宿主的阅读端、答疑面板、原生工具与预设档位在此不可用；需要原版体验按 `references/安装-原宿主.md` 自行装 DSH 插件（`dsh plugin --profile web add @yunmiao/studymate`）。
- 移植范围与版本溯源见 `references/SOURCE.md`。
