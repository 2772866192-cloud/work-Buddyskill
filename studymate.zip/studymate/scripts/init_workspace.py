#!/usr/bin/env python3
"""初始化 StudyMate 学习工作区，或在工作区里新建一门科目。

替代 DSH 侧安装器的工作区初始化部分。只用标准库。

skill 包只允许两级目录，模板在 `assets/` 下是扁平的 `tpl__*` 文件，
需要完整目录树时用同目录的 restore_templates.py 还原。

用法:
    python init_workspace.py [--workspace PATH] [--subject SLUG] [--name 名称] [--goal 目标]

不带 --subject 时只初始化工作区；带 --subject 时同时建科目骨架。
输出一段 JSON，便于上层 agent 直接读取（不要复算）。
"""

import argparse
import json
import re
import shutil
import sys
from datetime import date
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parents[1]
ASSETS = SKILL_DIR / "assets"


def tpl(name: str) -> Path:
    """把原 templates/ 下的名字换成包内的扁平文件名。"""
    return ASSETS / f"tpl__{name}"


SUBJECT_DIRS = ["lessons", "attempts", "learning-records", "reference"]
# lab/ 与 sources/ 刻意不预建：只有首个实操/实验节点才需要 lab，真抓过在线来源才有 sources。


def copy_if_absent(src: Path, dst: Path, created: list) -> None:
    if dst.exists():
        return
    if not src.exists():
        raise FileNotFoundError(f"缺模板文件: {src.name}")
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
    created.append(str(dst))


def init_workspace(ws: Path, created: list, existing: list) -> None:
    learn = ws / ".learning"
    (learn / "subjects").mkdir(parents=True, exist_ok=True)
    (ws / "export").mkdir(parents=True, exist_ok=True)

    mem = learn / "MEMORY.yaml"
    if mem.exists():
        existing.append(str(mem))
    else:
        copy_if_absent(tpl("MEMORY.yaml"), mem, created)

    readme = ws / "README.md"
    if readme.exists():
        existing.append(str(readme))
    else:
        readme.write_text(
            "# StudyMate 学习工作区\n\n"
            "本目录存放学习数据，与会话目录隔离。\n\n"
            "- `.learning/MEMORY.yaml` — 跨科目共享记忆（我是谁 / 教学偏好 / 学习习惯 / 积累）\n"
            "- `.learning/subjects/<slug>/` — 每门科目一份文件夹\n"
            "- `export/` — 课件渲染出的 HTML 页面\n\n"
            "布局与文件归属见 skill 的 `references/spec__文件归属.md`。\n",
            encoding="utf-8",
        )
        created.append(str(readme))


def fill_subject_yaml(template: Path, slug: str, name: str, goal: str) -> str:
    values = {
        "name": name,
        "slug": slug,
        "goal": goal,
        "created_at": date.today().isoformat(),
        "status": "进行中",
    }
    out = []
    for line in template.read_text(encoding="utf-8").splitlines():
        m = re.match(r"^([a-z_]+):\s*(.*)$", line)
        if not m or m.group(1) not in values:
            out.append(line)
            continue
        key, rest = m.group(1), m.group(2)
        comment = ""
        if "#" in rest:
            comment = "  #" + rest.split("#", 1)[1]
        out.append(f'{key}: "{values[key]}"{comment}')
    return "\n".join(out) + "\n"


def create_subject(ws: Path, slug: str, name: str, goal: str, created: list) -> Path:
    if not re.fullmatch(r"[a-z0-9]+(-[a-z0-9]+)*", slug):
        raise ValueError(f"slug 必须是小写连字符形式: {slug}")
    subject = ws / ".learning" / "subjects" / slug
    if subject.exists():
        raise FileExistsError(f"科目已存在，不覆盖: {subject}")

    for d in SUBJECT_DIRS:
        (subject / d).mkdir(parents=True, exist_ok=True)

    (subject / "subject.yaml").write_text(
        fill_subject_yaml(tpl("subject.yaml"), slug, name or slug, goal),
        encoding="utf-8",
    )
    created.append(str(subject / "subject.yaml"))

    for src_name, dst_name in [
        ("MISSION.md", "MISSION.md"),
        ("RESOURCES.md", "RESOURCES.md"),
        ("GLOSSARY.md", "GLOSSARY.md"),
        ("subject-MEMORY.yaml", "MEMORY.yaml"),
    ]:
        copy_if_absent(tpl(src_name), subject / dst_name, created)

    return subject


def main() -> int:
    parser = argparse.ArgumentParser(description="初始化 StudyMate 学习工作区 / 新建科目")
    parser.add_argument("--workspace", default=str(Path.home() / "StudyMate"), help="学习工作区路径（默认 ~/StudyMate）")
    parser.add_argument("--subject", default=None, help="要新建的科目 slug，如 python-basics")
    parser.add_argument("--name", default="", help="科目显示名")
    parser.add_argument("--goal", default="", help="科目目标（一句话）")
    args = parser.parse_args()

    ws = Path(args.workspace).expanduser().resolve()
    created: list = []
    existing: list = []

    try:
        init_workspace(ws, created, existing)
        subject = None
        if args.subject:
            subject = create_subject(ws, args.subject, args.name, args.goal, created)
    except (OSError, ValueError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2))
        return 1

    result = {
        "ok": True,
        "workspace": str(ws),
        "subject_path": str(subject) if subject else None,
        "created": created,
        "existing_kept": existing,
        "not_created": ["lab/", "sources/"],
        "templates": f"{ASSETS} 下的 tpl__* 扁平模板",
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
