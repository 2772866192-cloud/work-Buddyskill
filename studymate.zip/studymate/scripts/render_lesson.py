#!/usr/bin/env python3
"""轻量阅读端：把课件内容文件 + 题库渲染成自包含的单文件 HTML。

替代 DSH 的「阅读端 / studymate_export」。只做呈现，不改内容文件；图片内嵌为 data URI，
产物离线可打开。公式以 TeX 原文显示（不引 CDN），需要排版时可自行接 KaTeX。

用法:
    python render_lesson.py <课件.md> [<课件.md> ...] [-o 输出目录]
    python render_lesson.py --subject <科目目录> [-o 输出目录]
"""

import argparse
import base64
import html
import json
import mimetypes
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from validate import parse_curriculum_nodes  # noqa: E402

CSS = """
:root{--bg:#faf9f7;--fg:#22201d;--muted:#6b665f;--line:#e3ded6;--card:#fff;--accent:#8a5a2b;
--ok:#1a7f4b;--no:#b23c3c;--code-bg:#f3f0eb}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);
font:16px/1.75 -apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif}
.layout{display:grid;grid-template-columns:220px minmax(0,860px);gap:40px;max-width:1180px;margin:0 auto;padding:40px 24px}
nav{position:sticky;top:40px;align-self:start;font-size:14px;color:var(--muted)}
nav a{display:block;padding:5px 0;color:var(--muted);text-decoration:none}
nav a:hover{color:var(--accent)}nav .brand{font-weight:700;color:var(--fg);margin-bottom:18px}
nav .sec{margin-top:18px;font-size:12px;letter-spacing:.1em;text-transform:uppercase}
h1{font-size:30px;line-height:1.3;margin:8px 0 14px}h2{font-size:22px;margin:38px 0 14px;padding-bottom:8px;border-bottom:1px solid var(--line)}
h3{font-size:18px;margin:26px 0 10px}p{margin:12px 0}ul,ol{padding-left:24px}
.eyebrow{color:var(--accent);font-size:13px;letter-spacing:.08em;font-weight:600}
.goal{background:#f1ece4;border-left:3px solid var(--accent);padding:12px 16px;border-radius:4px;margin:18px 0 30px}
code{background:var(--code-bg);padding:2px 5px;border-radius:3px;font-size:.9em;font-family:ui-monospace,Consolas,monospace}
pre{background:var(--code-bg);padding:16px;border-radius:6px;overflow:auto;border:1px solid var(--line)}
pre code{background:none;padding:0}pre[data-lang]::before{content:attr(data-lang);display:block;color:var(--muted);font-size:11px;margin-bottom:8px;text-transform:uppercase;letter-spacing:.08em}
.box{background:var(--card);border:1px solid var(--line);border-left:3px solid var(--accent);border-radius:6px;padding:14px 18px;margin:18px 0}
.box .head{font-weight:700;margin-bottom:6px}.box.warn{border-left-color:#c47f1a}.box.note{border-left-color:#5a7a9a}
.level{display:inline-block;background:#eee7dc;color:var(--accent);font-size:12px;padding:2px 9px;border-radius:12px;margin-right:8px}
figure{margin:22px 0;text-align:center}figure img{max-width:100%;border-radius:5px;border:1px solid var(--line)}
figcaption{color:var(--muted);font-size:13px;margin-top:8px}
.quiz{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:18px 20px;margin:22px 0}
.quiz .q{font-weight:600;margin:0 0 10px}.quiz .opts{display:grid;gap:7px;margin:12px 0}
.quiz label{display:block;padding:9px 12px;border:1px solid var(--line);border-radius:5px;cursor:pointer}
.quiz label:hover{border-color:var(--accent)}.quiz button{margin-top:10px;padding:7px 16px;border:1px solid var(--accent);
background:var(--accent);color:#fff;border-radius:5px;cursor:pointer}
.feedback{margin-top:10px;padding:10px 12px;border-radius:5px;display:none;font-size:14px}
.feedback.ok{background:#e9f6ee;color:var(--ok)}.feedback.no{background:#fbecec;color:var(--no)}
details{margin:12px 0;background:var(--code-bg);border-radius:5px;padding:10px 14px}
summary{cursor:pointer;font-weight:600;color:var(--accent)}table{border-collapse:collapse;width:100%;margin:16px 0}
th,td{border:1px solid var(--line);padding:8px 12px;text-align:left}th{background:#f3f0eb}
.math{color:var(--accent)}.empty{color:var(--muted);font-style:italic}
.pager{display:flex;justify-content:space-between;gap:16px;margin-top:56px;padding-top:20px;border-top:1px solid var(--line)}
.pager a{color:var(--accent});text-decoration:none}.pager .disabled{color:#bbb}
@media(max-width:860px){.layout{grid-template-columns:1fr}nav{position:static}}
@media print{nav{display:none}.layout{display:block;padding:0}}
"""

JS = """
function check(btn){
  var box=btn.closest('.quiz'), picked=box.querySelector('input:checked'), fb=box.querySelector('.feedback');
  if(!picked){fb.className='feedback no';fb.textContent='先选一个选项';fb.style.display='block';return;}
  var ok=Number(picked.value)===Number(box.dataset.ans);
  fb.className='feedback '+(ok?'ok':'no');
  fb.textContent=(ok?'✓ 对了。':'✗ 再想想。')+' '+(box.dataset.why||'');
  fb.style.display='block';
}
"""


def inline(s: str) -> str:
    codes = []

    def stash(m):
        codes.append(m.group(1))
        return f"\x00C{len(codes) - 1}\x00"

    s = re.sub(r"`([^`]+)`", stash, s)
    s = html.escape(s, quote=False)
    s = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", s)
    s = re.sub(r"(?<![\w*])\*([^\s*][^*]*?)\*(?!\w)", r"<em>\1</em>", s)
    s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)",
               lambda m: f'<a href="{html.escape(m.group(2), quote=True)}">{m.group(1)}</a>', s)
    s = re.sub(r"(?<!\\)\$([^\s$][^$]*?[^\s$])\$", r'<code class="math">\1</code>', s)
    s = re.sub(r"\x00C(\d+)\x00",
               lambda m: f"<code>{html.escape(codes[int(m.group(1))])}</code>", s)
    return s


def tokenize(text: str):
    lines = text.splitlines()
    fm, events = {}, []
    i = 0
    if lines and lines[0].strip() == "---":
        i = 1
        while i < len(lines) and lines[i].strip() != "---":
            m = re.match(r"^([A-Za-z_][\w-]*):\s*(.*)$", lines[i])
            if m:
                fm[m.group(1)] = m.group(2).strip()
            i += 1
        i += 1
    while i < len(lines):
        line = lines[i]
        s = line.strip()
        if not s:
            i += 1
            continue
        if s.startswith("```"):
            lang = s[3:].strip()
            body = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith("```"):
                body.append(lines[i])
                i += 1
            i += 1
            events.append(("fence", (lang, body)))
            continue
        dm = re.match(r"^:::\s+([A-Za-z]+)(.*)$", s)
        if dm:
            name, arg = dm.group(1), dm.group(2).strip()
            body = []
            i += 1
            while i < len(lines) and lines[i].strip() != ":::":
                body.append(lines[i])
                i += 1
            i += 1
            events.append(("block", (name, arg, body)))
            continue
        if s.startswith("|") and i + 1 < len(lines) and re.match(r"^\|[\s:\-|]+\|$", lines[i + 1].strip()):
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                rows.append([c.strip() for c in lines[i].strip().strip("|").split("|")])
                i += 1
            events.append(("table", rows))
            continue
        hm = re.match(r"^(#{2,3})\s+(.+)$", s)
        if hm:
            events.append(("heading", (len(hm.group(1)), hm.group(2))))
            i += 1
            continue
        lm = re.match(r"^(\s*)(-|\d+\.)\s+(.+)$", line)
        if lm:
            ordered = not lm.group(2) == "-"
            items = []
            while i < len(lines):
                m2 = re.match(r"^(\s*)(-|\d+\.)\s+(.+)$", lines[i])
                if not m2:
                    break
                items.append((len(m2.group(1)), m2.group(3)))
                i += 1
            events.append(("list", (ordered, items)))
            continue
        para = []
        while i < len(lines) and lines[i].strip() and not re.match(
                r"^(```|:::|#{2,3}\s|\||\s*-\s|\s*\d+\.\s)", lines[i]):
            para.append(lines[i].strip())
            i += 1
        if para:
            # 段内换行：两侧都是中文就直接相接，否则补空格
            joined = ""
            for part in para:
                if joined and re.search(r"[\u4e00-\u9fff]$", joined) and re.match(r"^[\u4e00-\u9fff]", part):
                    joined += part
                else:
                    joined = (joined + " " + part).strip()
            events.append(("para", joined))
        else:
            i += 1
    return fm, events


def render_list(ordered, items):
    tag = "ol" if ordered else "ul"
    out = [f"<{tag}>"]
    open_sub = False
    for indent, text in items:
        if indent > 0 and not open_sub:
            out.append(f"<{tag}>")
            open_sub = True
        elif indent == 0 and open_sub:
            out.append(f"</{tag}>")
            open_sub = False
        out.append(f"<li>{inline(text)}</li>")
    if open_sub:
        out.append(f"</{tag}>")
    out.append(f"</{tag}>")
    return "".join(out)


def render_fence(lang, body):
    attr = f' data-lang="{html.escape(lang, quote=True)}"' if lang else ""
    return f"<pre{attr}><code>{html.escape(chr(10).join(body))}</code></pre>"


def render_quiz(anchor, questions, empty_reason):
    if not questions:
        return (f'<div class="quiz"><p class="empty">本轮不出题'
                f'{("：" + html.escape(empty_reason)) if empty_reason else ""}</p></div>')
    out = []
    for q in questions:
        if not isinstance(q, dict):
            continue
        kind = q.get("kind", "")
        objective = kind == "客观题" or ("opts" in q and "ans" in q)
        attrs = ""
        if objective:
            attrs = (f' data-ans="{q.get("ans", -1)}" '
                     f'data-why="{html.escape(str(q.get("why", "")), quote=True)}"')
        out.append(f'<div class="quiz"{attrs}>')
        out.append(f'<p class="q">{inline(str(q.get("q", "")))}</p>')
        if objective:
            out.append('<div class="opts">')
            for idx, opt in enumerate(q.get("opts", [])):
                out.append(f'<label><input type="radio" name="q{id(q)}" value="{idx}"> {inline(str(opt))}</label>')
            out.append("</div>")
            out.append('<button type="button" onclick="check(this)">提交</button>')
            out.append('<div class="feedback"></div>')
        else:
            parts = []
            for k in ["预测", "比对", "answer", "criteria", "交付物", "证据"]:
                if q.get(k):
                    parts.append(f"<p><b>{html.escape(k)}</b>：{inline(str(q[k]))}</p>")
            if parts:
                out.append(f'<details><summary>参考答案 / 判分要点</summary>{"".join(parts)}</details>')
        out.append("</div>")
    return "".join(out)


def render_block(name, arg, body, lesson_path, fig_no, quiz_data):
    inline_body = lambda: "".join(
        render_plain_token(t) for t in tokenize("\n".join(body))[1]
    )
    if name in {"tip", "warn", "note", "practice"}:
        cls = {"tip": "box", "warn": "box warn", "note": "box note", "practice": "box"}[name]
        head = f'<div class="head">{inline(arg)}</div>' if arg and name != "practice" else (
            f'<span class="level">{inline(arg.split("|")[0].strip())}</span>'
            f'<b>{inline(arg.split("|", 1)[1].strip())}</b>' if name == "practice" and "|" in arg else "")
        return f'<div class="{cls}">{head}{inline_body()}</div>'
    if name == "quiz":
        m = re.search(r"锚点\s*[:：]\s*(.+?)\s*$", arg)
        anchor = m.group(1).strip() if m else ""
        reason = ""
        for l in body:
            em = re.match(r"^empty_reason:\s*(.+)$", l.strip())
            if em:
                reason = em.group(1)
        return render_quiz(anchor, (quiz_data or {}).get(anchor, []), reason)
    if name == "figure":
        target = arg.split()[0] if arg else ""
        alt = caption = ""
        for l in body:
            if l.strip().startswith("alt:"):
                alt = l.split(":", 1)[1].strip()
            elif l.strip().startswith("caption:"):
                caption = l.split(":", 1)[1].strip()
        src = ""
        p = (lesson_path.parent / target)
        if p.exists() and p.is_file():
            mime = mimetypes.guess_type(p.name)[0] or "image/png"
            src = f"data:{mime};base64,{base64.b64encode(p.read_bytes()).decode()}"
        else:
            src = html.escape(target, quote=True)
        fig_no[0] += 1
        cap = f"<figcaption>图 {fig_no[0]} · {inline(caption)}</figcaption>" if caption else ""
        return f'<figure><img src="{src}" alt="{html.escape(alt, quote=True)}">{cap}</figure>'
    if name == "svg":
        alt = caption = ""
        svg_lines = []
        for l in body:
            st = l.strip()
            if st.startswith("alt:"):
                alt = st.split(":", 1)[1].strip()
                continue
            if st.startswith("caption:"):
                caption = st.split(":", 1)[1].strip()
                continue
            svg_lines.append(l)
        fig_no[0] += 1
        cap = f"<figcaption>图 {fig_no[0]} · {inline(caption)}</figcaption>" if caption else ""
        label = f' aria-label="{html.escape(alt, quote=True)}"' if alt else ""
        return f'<figure class="lesson-figure--inline"{label}>{"".join(svg_lines)}{cap}</figure>'
    if name == "code":
        lang = arg.split()[0] if arg else ""
        caption = ""
        rest = []
        for l in body:
            if l.strip().startswith("alt:") or l.strip().startswith("caption:"):
                if l.strip().startswith("caption:"):
                    caption = l.split(":", 1)[1].strip()
                continue
            rest.append(l)
        return render_fence(lang, rest) + (f'<p class="empty">{inline(caption)}</p>' if caption else "")
    if name in {"resources", "related"}:
        items = [l.strip()[2:] for l in body if l.strip().startswith("- ")]
        return '<div class="box"><div class="head">' + (
            "本节资源" if name == "resources" else "相关课件") + "</div><ul>" + \
            "".join(f"<li>{inline(x)}</li>" for x in items) + "</ul></div>"
    return f'<div class="box">{inline(arg)}{inline_body()}</div>'


def render_plain_token(ev):
    kind, data = ev
    if kind == "para":
        return f"<p>{inline(data)}</p>"
    if kind == "heading":
        return f"<h{data[0]}>{inline(data[1])}</h{data[0]}>"
    if kind == "list":
        return render_list(*data)
    if kind == "fence":
        return render_fence(*data)
    if kind == "table":
        rows = data
        head = "<thead><tr>" + "".join(f"<th>{inline(c)}</th>" for c in rows[0]) + "</tr></thead>"
        body = "<tbody>" + "".join(
            "<tr>" + "".join(f"<td>{inline(c)}</td>" for c in r) + "</tr>" for r in rows[2:]) + "</tbody>"
        return f"<table>{head}{body}</table>"
    return ""


def build(lesson_path: Path, out_dir: Path, neighbours: dict) -> Path:
    text = lesson_path.read_text(encoding="utf-8")
    fm, events = tokenize(text)
    quiz_path = lesson_path.with_suffix(".quiz.json")
    quiz_data = {}
    if quiz_path.exists():
        try:
            quiz_data = json.loads(quiz_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            quiz_data = {}
    title = fm.get("title", lesson_path.stem)
    goal = fm.get("goal", "")
    toc, body, fig_no = [], [], [0]
    for ev in events:
        if ev[0] == "heading" and ev[1][0] == 2:
            anchor_id = "h" + str(len(toc) + 1)
            toc.append(f'<a href="#{anchor_id}">{html.escape(ev[1][1])}</a>')
            body.append(f'<h2 id="{anchor_id}">{inline(ev[1][1])}</h2>')
        elif ev[0] == "block":
            body.append(render_block(ev[1][0], ev[1][1], ev[1][2], lesson_path, fig_no, quiz_data))
        else:
            body.append(render_plain_token(ev))
    prev_link, next_link = neighbours.get(lesson_path.stem, (None, None))
    pager = '<div class="pager">'
    pager += f'<a href="{html.escape(prev_link, quote=True)}.html">← 上一课</a>' if prev_link else '<span class="disabled">← 上一课</span>'
    pager += f'<a href="{html.escape(next_link, quote=True)}.html">下一课 →</a>' if next_link else '<span class="disabled">下一课 →</span>'
    pager += "</div>"
    doc = f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>{html.escape(title)}</title>
<style>{CSS}</style></head><body><div class="layout">
<nav><div class="brand">StudyMate</div><div class="sec">本节目录</div>{''.join(toc)}
<div class="sec">课程</div><a href="index.html">科目主页</a></nav>
<main><div class="eyebrow">{html.escape(lesson_path.stem)}</div><h1>{html.escape(title)}</h1>
{f'<div class="goal"><b>本节目标：</b>{inline(goal)}</div>' if goal else ''}
{''.join(body)}{pager}</main></div><script>{JS}</script></body></html>"""
    out_dir.mkdir(parents=True, exist_ok=True)
    target = out_dir / (lesson_path.stem + ".html")
    target.write_text(doc, encoding="utf-8")
    return target


def main() -> int:
    p = argparse.ArgumentParser(description="把 StudyMate 课件渲染成自包含 HTML")
    p.add_argument("paths", nargs="*", type=Path, help="课件内容文件路径")
    p.add_argument("--subject", type=Path, default=None, help="渲染该科目 lessons/ 下所有课件")
    p.add_argument("-o", "--out", type=Path, default=None, help="输出目录")
    args = p.parse_args()

    lessons = []
    subject = None
    if args.subject:
        subject = args.subject.resolve()
        lessons = sorted((subject / "lessons").glob("*.md"))
        if not lessons:
            print(f"没找到课件：{subject / 'lessons'}", file=sys.stderr)
            return 2
    elif args.paths:
        lessons = [p.resolve() for p in args.paths]
        subject = lessons[0].parent.parent
    else:
        p.print_help()
        return 2

    default_out = subject.parents[2] / "export" if len(subject.parents) >= 3 else subject / "export"
    out = (args.out or default_out).resolve()
    stems = [l.stem for l in lessons]
    neighbours = {s: (stems[i - 1] if i > 0 else None,
                      stems[i + 1] if i + 1 < len(stems) else None)
                  for i, s in enumerate(stems)}
    made = [build(l, out, neighbours) for l in lessons]

    # 科目主页：按大纲顺序列课件
    cur = subject / "curriculum.yaml"
    nodes = parse_curriculum_nodes(cur.read_text(encoding="utf-8")) if cur.exists() else []
    sfile = subject / "subject.yaml"
    name = subject.name
    if sfile.exists():
        m = re.search(r'^name:\s*"?([^"#\n]+)"?', sfile.read_text(encoding="utf-8"), re.M)
        if m:
            name = m.group(1).strip()
    cards = "".join(
        f'<li><a href="{html.escape(s, quote=True)}.html">{html.escape(s)}</a></li>' for s in stems)
    roadmap = "".join(f"<li>{html.escape(n.get('title', n['id']))} · {html.escape(n.get('kind', ''))}</li>"
                      for n in nodes)
    (out / "index.html").write_text(
        f'<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">'
        f'<meta name="viewport" content="width=device-width,initial-scale=1">'
        f'<title>{html.escape(name)}</title><style>{CSS}</style></head><body>'
        f'<div class="layout"><nav><div class="brand">StudyMate</div></nav><main>'
        f'<h1>{html.escape(name)}</h1><div class="box"><div class="head">课件（{len(stems)}）</div><ul>{cards}</ul></div>'
        f'<h2>课程路线图</h2><ol>{roadmap}</ol></main></div></body></html>', encoding="utf-8")

    for f in made:
        print(f"已生成 {f}")
    print(f"科目主页 {out / 'index.html'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
