#!/usr/bin/env python3
"""StudyMate 本地校验器 —— 替代 DSH 的 studymate_validate_* 系列原生工具。

只用 Python 标准库。每个子命令输出「文件:行号 + 是否阻断」的逐条问题，末尾给一句结论。
退出码：0 通过（含提示），1 有阻断项，2 用法/读取错误。

子命令:
    workspace  <工作区>                    开场摘要：记忆分节、科目清单、当前节点
    curriculum <curriculum.yaml>          节点 DAG：id/kind/status、前置引用、环
    lesson     <课件.md>                  内容格式、锚点 ↔ 题库对账、配图
    handoff    <deliver目录> <科目目录>    交接门禁：路径合法性 + 文件清单（--apply 原样搬入）
"""

import argparse
import json
import re
import shutil
import sys
from pathlib import Path

KINDS = {"概念", "实操", "实验"}
STATUSES = {"未开始", "学习中", "已学完"}
QUESTION_KINDS = {"客观题", "预测验证", "开放题", "交付物"}
REQUIRED_BY_KIND = {
    "客观题": ["opts", "ans", "why"],
    "预测验证": ["预测", "比对"],
    "开放题": ["answer", "criteria"],
    "交付物": ["交付物", "证据", "criteria"],
}
DIRECTIVES = {"practice", "quiz", "figure", "svg", "code", "tip", "warn", "note", "resources", "related"}
# 正文里不许写真标签；这是规范里 HTML_TAG_NAMES 的常用子集（svg 块与代码围栏内不检查）。
BANNED_TAGS = set(
    "a abbr b basefont bdi bdo big blockquote body br button canvas caption center cite code col "
    "colgroup data datalist dd del details dfn dialog div dl dt em embed fieldset figcaption figure "
    "footer form frame frameset h1 h2 h3 h4 h5 h6 head header hgroup hr html i iframe img input ins "
    "label legend li link main map mark marquee menu meta meter nav nobr object ol optgroup option "
    "output p param picture pre progress q rp rt ruby s samp script section select slot small source "
    "span strike strong style sub summary sup svg table tbody td template textarea tfoot th thead time "
    "title tr track tt u ul var video wbr xmp".split()
)
TAG_RE = re.compile(r"<(/?)([A-Za-z][A-Za-z0-9]*)\b[^>]*>")
QUIZ_RE = re.compile(r"锚点\s*[:：]\s*(.+?)\s*$")


class Report:
    def __init__(self):
        self.items: list[tuple[bool, str]] = []

    def block(self, msg: str):
        self.items.append((True, msg))

    def note(self, msg: str):
        self.items.append((False, msg))

    def finish(self) -> int:
        for blocking, msg in self.items:
            print(f"[{'阻断' if blocking else '提示'}] {msg}")
        blocked = sum(1 for b, _ in self.items if b)
        print(f"结论: {'阻断 %d 条' % blocked if blocked else '通过'}"
              f"（提示 {len(self.items) - blocked} 条）")
        return 1 if blocked else 0


def top_fields(text: str) -> dict:
    """读取 YAML 顶层的简单 `key: value` 字段（不解析嵌套，够做存在性与枚举检查）。"""
    out = {}
    for line in text.splitlines():
        m = re.match(r"^([A-Za-z_][\w-]*):\s*(.*?)\s*(?:#.*)?$", line)
        if m:
            v = m.group(2).strip().strip('"').strip("'")
            out[m.group(1)] = v
    return out


def parse_curriculum_nodes(text: str) -> list[dict]:
    """按 `- id:` 切块，抽取校验需要的字段。"""
    lines = text.splitlines()
    starts = [(i, m) for i, l in enumerate(lines)
              if (m := re.match(r"^(\s*)-\s+id:\s*([^\s#]+)", l))]
    nodes = []
    for idx, (start, m) in enumerate(starts):
        end = starts[idx + 1][0] if idx + 1 < len(starts) else len(lines)
        base = len(m.group(1))
        chunk = lines[start:end]
        node = {"id": m.group(2).strip('"\''), "line": start + 1, "prerequisites": [], "resources": 0}
        section = None
        section_indent = 0
        for l in chunk:
            stripped = l.strip()
            if not stripped or stripped.startswith("#"):
                continue
            indent = len(l) - len(l.lstrip())
            fm = re.match(r"^\s*-\s+(.+?)\s*$", l)
            if fm:
                item = fm.group(1).strip().strip('"\'')
                if section == "prerequisites" and indent > section_indent and not re.match(r"^[A-Za-z_][\w-]*\s*:", item):
                    node["prerequisites"].append(item)
                elif section == "resources" and indent > section_indent:
                    node["resources"] += 1
                continue
            km = re.match(r"^\s*([A-Za-z_][\w-]*):\s*(.*?)\s*$", l)
            if not km:
                continue
            key, val = km.group(1), km.group(2).strip().strip('"\'').strip()
            if indent <= base + 2 and key in {"kind", "title", "status", "objective"}:
                node[key] = val
            if key in {"prerequisites", "resources", "concepts", "pitfalls"}:
                section, section_indent = key, indent
                if key == "prerequisites" and val.startswith("["):
                    node["prerequisites"] = [x.strip().strip('"\'')
                                             for x in val.strip("[]").split(",") if x.strip()]
            elif indent <= base + 2:
                section = None
        nodes.append(node)
    return nodes


# ---------------------------------------------------------------- workspace

def cmd_workspace(ws: Path, rep: Report) -> None:
    learn = ws / ".learning"
    mem = learn / "MEMORY.yaml"
    if not mem.exists():
        rep.block(f"{mem}: 共享记忆缺失，先跑 init_workspace.py")
    else:
        text = mem.read_text(encoding="utf-8")
        for section in ["我是谁", "教学偏好", "学习习惯", "积累"]:
            if not re.search(rf"^{re.escape(section)}\s*:", text, re.M):
                rep.block(f"{mem}: 缺分节「{section}」")
    subjects_dir = learn / "subjects"
    subjects = []
    if subjects_dir.is_dir():
        for d in sorted(p for p in subjects_dir.iterdir() if p.is_dir()):
            sfile = d / "subject.yaml"
            info = {"slug": d.name, "path": str(d)}
            if not sfile.exists():
                rep.block(f"{d}: 缺 subject.yaml")
            else:
                f = top_fields(sfile.read_text(encoding="utf-8"))
                info.update({k: f.get(k, "") for k in ["name", "goal", "status", "created_at"]})
                for k in ["name", "slug", "goal", "created_at", "status"]:
                    if not f.get(k):
                        rep.block(f"{sfile}: 缺字段 {k}")
            cur = d / "curriculum.yaml"
            prog = d / "progress.yaml"
            if cur.exists():
                nodes = parse_curriculum_nodes(cur.read_text(encoding="utf-8"))
                info["node_count"] = len(nodes)
                info["curriculum"] = str(cur)
                if not nodes:
                    rep.block(f"{cur}: 解析不到任何节点")
            else:
                rep.note(f"{d.name}: 还没有课程大纲")
            if not prog.exists():
                rep.note(f"{d.name}: 还没有学习进度")
            else:
                info["progress"] = str(prog)
            subjects.append(info)
    if not subjects:
        rep.note("工作区里还没有科目")
    print("--- 工作区摘要 JSON ---")
    print(json.dumps({"workspace": str(ws), "subjects": subjects}, ensure_ascii=False, indent=2))
    print("--- 校验 ---")


# --------------------------------------------------------------- curriculum

def cmd_curriculum(path: Path, rep: Report) -> None:
    nodes = parse_curriculum_nodes(path.read_text(encoding="utf-8"))
    where = lambda n: f"{path.name}:{n['line']}"
    if not nodes:
        rep.block(f"{path}:1 解析不到节点（需要 `nodes:` 下的 `- id: ...`）")
        return
    ids = [n["id"] for n in nodes]
    for dup in {x for x in ids if ids.count(x) > 1}:
        rep.block(f"{path.name}: 节点 id 重复「{dup}」")
    idset = set(ids)
    for n in nodes:
        if n.get("kind") and n["kind"] not in KINDS:
            rep.block(f"{where(n)} kind「{n['kind']}」不在词表（概念/实操/实验）")
        if n.get("status") and n["status"] not in STATUSES:
            rep.block(f"{where(n)} status「{n['status']}」不在词表")
        for pre in n["prerequisites"]:
            if pre not in idset:
                rep.block(f"{where(n)} prerequisites 引用了不存在的节点「{pre}」")
    # 环检测
    graph = {n["id"]: [p for p in n["prerequisites"] if p in idset] for n in nodes}
    state = {}

    def visit(v, stack):
        if state.get(v) == 1:
            cycle = " -> ".join(stack[stack.index(v):] + [v])
            rep.block(f"{path.name}: 前置依赖成环 {cycle}")
            return
        if state.get(v) == 2:
            return
        state[v] = 1
        for w in graph.get(v, []):
            visit(w, stack + [v])
        state[v] = 2

    for v in graph:
        visit(v, [])
    total_res = sum(n["resources"] for n in nodes)
    if total_res > len(nodes) * 2:
        rep.note(f"{path.name}: 资源条目 {total_res} 条 > 节点数 × 2（{len(nodes) * 2}），考虑精简")
    if not any(n.get("kind") == "实验" for n in nodes):
        rep.note(f"{path.name}: 没有 kind: 实验 的节点，项目里程碑缺载体")
    print(f"节点 {len(nodes)} 个；资源 {total_res} 条；"
          f"课型分布 " + ", ".join(f"{k}={sum(1 for n in nodes if n.get('kind') == k)}" for k in sorted(KINDS)))


# ------------------------------------------------------------------- lesson

def parse_lesson(text: str):
    """返回 (frontmatter dict, 指令块列表, 普通正文行列表)。"""
    lines = text.splitlines()
    fm = {}
    body_start = 0
    if lines and lines[0].strip() == "---":
        for i in range(1, len(lines)):
            if lines[i].strip() == "---":
                body_start = i + 1
                break
            m = re.match(r"^([A-Za-z_][\w-]*):\s*(.*)$", lines[i])
            if m:
                fm[m.group(1)] = m.group(2).strip()
    blocks = []
    plain = []
    open_block = None
    in_fence = False
    for i in range(body_start, len(lines)):
        line = lines[i]
        stripped = line.strip()
        if re.match(r"^```", stripped):
            in_fence = not in_fence
            if open_block:
                open_block["body"].append(line)
            else:
                plain.append((i + 1, line))
            continue
        if in_fence:
            if open_block:
                open_block["body"].append(line)
            else:
                plain.append((i + 1, line))
            continue
        if open_block:
            if stripped == ":::":
                open_block["end"] = i + 1
                blocks.append(open_block)
                open_block = None
            else:
                open_block["body"].append(line)
            continue
        m = re.match(r"^:::\s+([A-Za-z]+)(.*)$", stripped)
        if m:
            open_block = {"name": m.group(1), "arg": m.group(2).strip(), "line": i + 1,
                          "body": [], "end": None}
            continue
        plain.append((i + 1, line))
    if open_block:
        blocks.append({**open_block, "unclosed": True})
    return fm, blocks, plain


def cmd_lesson(path: Path, rep: Report) -> None:
    text = path.read_text(encoding="utf-8")
    fm, blocks, plain = parse_lesson(text)
    tag = lambda n: f"{path.name}:{n}"

    for k in ["title", "goal"]:
        if not fm.get(k):
            rep.block(f"{path.name}:1 front matter 缺 {k}")
    extra = set(fm) - {"title", "goal"}
    if extra:
        rep.block(f"{path.name}:1 front matter 多出字段 {sorted(extra)}（只允许 title / goal）")
    if fm.get("title") and len(fm["title"]) > 16:
        rep.note(f"{path.name}:1 title 超过 16 字，建议缩短")

    # 与课程大纲里的 title 对账
    cur = path.parent.parent / "curriculum.yaml"
    node_id = re.sub(r"^\d+-", "", path.stem)
    if cur.exists():
        nodes = parse_curriculum_nodes(cur.read_text(encoding="utf-8"))
        match = next((n for n in nodes if n["id"] == node_id), None)
        if not match:
            rep.note(f"{cur.name}: 找不到节点 id「{node_id}」（文件名序号后的部分）")
        elif match.get("title") and fm.get("title") and match["title"] != fm["title"]:
            rep.block(f"{path.name}:1 title「{fm['title']}」与大纲「{match['title']}」不一致")

    anchors: list[str] = []
    empty: set[str] = set()
    for b in blocks:
        if b.get("unclosed"):
            rep.block(f"{tag(b['line'])} 指令 ::: {b['name']} 没有闭合")
        if b["name"] not in DIRECTIVES:
            rep.block(f"{tag(b['line'])} 未知指令 ::: {b['name']}")
            continue
        body = b["body"]
        if b["name"] == "quiz":
            m = QUIZ_RE.search(b["arg"])
            if not m:
                rep.block(f"{tag(b['line'])} quiz 块缺「锚点：」")
                continue
            anchor = m.group(1).strip()
            if anchor in anchors:
                rep.block(f"{tag(b['line'])} 锚点「{anchor}」被两个题目位置引用")
            anchors.append(anchor)
            for line in body:
                em = re.match(r"^empty_reason:\s*(.+)$", line.strip())
                if em:
                    empty.add(anchor)
        elif b["name"] == "figure":
            target = b["arg"].split()[0] if b["arg"] else ""
            if not target:
                rep.block(f"{tag(b['line'])} figure 块缺图片路径")
            elif not (path.parent / target).exists():
                rep.block(f"{tag(b['line'])} 图片不存在：{(path.parent / target)}")
            if not any(l.strip().startswith("alt:") and l.split(":", 1)[1].strip() for l in body):
                rep.block(f"{tag(b['line'])} figure 块缺 alt:")
        elif b["name"] == "svg":
            joined = "\n".join(body)
            if "<svg" not in joined:
                rep.block(f"{tag(b['line'])} svg 块里没有 <svg>")
            elif "</svg" not in joined and "/>" not in joined:
                rep.block(f"{tag(b['line'])} svg 没有闭合（缺 </svg> 或自闭合）")
        elif b["name"] == "code":
            if not any(l.strip() and not re.match(r"^(alt|caption):", l.strip()) for l in body):
                rep.block(f"{tag(b['line'])} code 块只有字段、没有代码原文")

    # 正文不许真标签（跳过 svg 块与围栏；这里只扫 plain 行）
    for lineno, line in plain:
        for m in TAG_RE.finditer(line):
            if m.group(2).lower() in BANNED_TAGS:
                prev = line[m.start() - 1] if m.start() else ""
                if not (prev.isalnum() and prev.isascii()):
                    rep.block(f"{tag(lineno)} 正文里出现真标签 <{m.group(2)}>，用 ::: 指令或行内语法代替")
                    break

    quiz_path = path.with_suffix(".quiz.json")
    quiz = None
    if quiz_path.exists():
        try:
            quiz = json.loads(quiz_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as e:
            rep.block(f"{quiz_path.name}:{e.lineno} JSON 解析失败：{e.msg}")
    if quiz is not None:
        if not isinstance(quiz, dict):
            rep.block(f"{quiz_path.name}:1 题库顶层必须是对象（锚点 → 题目数组）")
        else:
            if not anchors and quiz:
                rep.block(f"{quiz_path.name}:1 内容里没有题目位置，题库却还在")
            for key, questions in quiz.items():
                if not isinstance(questions, list):
                    rep.block(f"{quiz_path.name}: 锚点「{key}」的值必须是题目数组")
                    continue
                if key not in anchors:
                    rep.block(f"{quiz_path.name}: 锚点「{key}」在内容里没有对应题目位置")
                if key in empty:
                    rep.block(f"{quiz_path.name}: 锚点「{key}」写了 empty_reason 却还有题")
                for qi, q in enumerate(questions):
                    if not isinstance(q, dict) or not str(q.get("q", "")).strip():
                        rep.block(f"{quiz_path.name}: 锚点「{key}」第 {qi + 1} 题缺题面 q")
                        continue
                    kind = q.get("kind")
                    if kind and kind not in QUESTION_KINDS:
                        rep.block(f"{quiz_path.name}: 题型「{kind}」不在词表（{'/'.join(sorted(QUESTION_KINDS))}）")
                    elif kind:
                        for field in REQUIRED_BY_KIND[kind]:
                            if field not in q:
                                rep.block(f"{quiz_path.name}: 锚点「{key}」第 {qi + 1} 题（{kind}）缺 {field}")
    for anchor in anchors:
        if anchor not in empty and (quiz is None or anchor not in (quiz if isinstance(quiz, dict) else {})):
            state = "题库文件还没产出（待对账）" if quiz is None else "题库里没有题"
            line = tag(1)
            if quiz is None:
                rep.note(f"{line} 锚点「{anchor}」{state}：补 empty_reason: 或让出题角色补题")
            else:
                rep.block(f"{line} 锚点「{anchor}」{state}：补 empty_reason: 或让出题角色补题")
    print(f"题目位置 {len(anchors)} 处；empty_reason {len(empty)} 处；"
          f"题库文件 {'在' if quiz_path.exists() else '不在'}")


# ------------------------------------------------------------------ handoff

def cmd_handoff(deliver: Path, subject: Path, apply: bool, rep: Report) -> None:
    if not deliver.is_dir():
        rep.block(f"{deliver}: deliver 目录不存在")
        return
    files = sorted(p for p in deliver.rglob("*") if p.is_file())
    if not files:
        rep.block(f"{deliver}: deliver 里没有文件")
    rels = []
    for f in files:
        rel = f.relative_to(deliver).as_posix()
        rels.append(rel)
        if rel.startswith("/") or ".." in Path(rel).parts or re.match(r"^[A-Za-z]:", rel):
            rep.block(f"{f}: 非法相对路径「{rel}」")
        target = (subject / rel).resolve()
        if subject.resolve() not in target.parents:
            rep.block(f"{f}: 目标逃逸出科目目录「{rel}」")
    print("--- deliver 清单 ---")
    for rel in rels:
        print(f"  {rel}")
    print(f"共 {len(rels)} 个文件")
    if apply and not any(b for b, _ in rep.items):
        for f, rel in zip(files, rels):
            dst = subject / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(f, dst)
        print(f"已原样搬入 {subject}（{len(files)} 个文件；stage 由调用方清理）")
    elif apply:
        print("有阻断项，未搬入；把上面的原文打回产出角色")


def main() -> int:
    p = argparse.ArgumentParser(description="StudyMate 本地校验器")
    sub = p.add_subparsers(dest="cmd", required=True)
    w = sub.add_parser("workspace"); w.add_argument("path", type=Path)
    c = sub.add_parser("curriculum"); c.add_argument("path", type=Path)
    l = sub.add_parser("lesson"); l.add_argument("path", type=Path)
    h = sub.add_parser("handoff")
    h.add_argument("deliver", type=Path); h.add_argument("subject", type=Path)
    h.add_argument("--apply", action="store_true", help="校验通过后原样搬入科目目录")
    args = p.parse_args()
    rep = Report()
    try:
        if args.cmd == "workspace":
            cmd_workspace(args.path, rep)
        elif args.cmd == "curriculum":
            cmd_curriculum(args.path, rep)
        elif args.cmd == "lesson":
            cmd_lesson(args.path, rep)
        elif args.cmd == "handoff":
            cmd_handoff(args.deliver, args.subject, args.apply, rep)
    except (OSError, UnicodeDecodeError) as exc:
        print(f"读取失败: {exc}", file=sys.stderr)
        return 2
    return rep.finish()


if __name__ == "__main__":
    sys.exit(main())
