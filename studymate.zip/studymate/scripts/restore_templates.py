#!/usr/bin/env python3
"""把 assets/ 下的 tpl__* 扁平模板还原成原仓库的 templates/ 目录树。

skill 包只允许两级目录（根 / 二级目录 / 文件），所以模板在包内被拍平：
`tpl__` 前缀之后，每一段 `__` 代表原路径里的一级 `/`。
例如 tpl__lab__0000-示例__check.sh → lab/0000-示例/check.sh。

用法:
    python restore_templates.py --out <WS>/templates
    python restore_templates.py --out <SUB>/lab --lab-only
"""

import argparse
import json
import shutil
import sys
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parents[1]
ASSETS = SKILL_DIR / "assets"


def main() -> int:
    p = argparse.ArgumentParser(description="还原 StudyMate 工作区模板目录树")
    p.add_argument("--out", required=True, type=Path, help="还原到的目标目录")
    p.add_argument("--lab-only", action="store_true",
                   help="只还原 lab/ 子树，且去掉 lab/ 前缀（直接生成到 --out 下）")
    args = p.parse_args()

    out = Path(args.out).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)
    made = []
    for f in sorted(ASSETS.glob("tpl__*")):
        if not f.is_file():
            continue
        rel = f.name[len("tpl__"):].replace("__", "/")
        if args.lab_only:
            if not rel.startswith("lab/"):
                continue
            rel = rel[len("lab/"):]
        dst = out / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(f, dst)
        made.append(rel)

    result = {
        "ok": bool(made),
        "output": str(out),
        "count": len(made),
        "files": made,
        "note": "tpl__* 是包内扁平模板；本脚本只还原目录结构，不改动工作区里的学习数据",
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if made else 1


if __name__ == "__main__":
    sys.exit(main())
