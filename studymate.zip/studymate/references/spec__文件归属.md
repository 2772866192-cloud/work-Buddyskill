# 文件归属（代称 ↔ 路径 ↔ 维护者）

**这份表是文件「代称、功能、路径、维护者」的唯一出处。** 角色规格（`preset/skills/*/SKILL.md`）在正文里用「代称」指代文件，不再反复写全路径；要判断自己有没有权改某份文件，查这张表的「维护者」一列。

## 怎么用

- 代称在 SKILL 正文里写作「共享记忆」这样用「」框住；本表第一列写裸名
- **角色也有代称**（见下节）：正文里可以直接用「总控」「讲解」这类叫法；**「维护者」一列写技能名**（按角色代称表对应），或者写 **`所有角色（直写）`**——后者表示这份文件不收在某个角色手里，谁在干活谁收尾时自己往里写，不经总控转交。今天只有两份记忆是 `所有角色（直写）`：往「积累」追加一行，判据与写法见 `record-keeping` 的「共享记忆」节
- **路径前缀**：`<root>` = 引擎仓库根；`<LEARN_WORKSPACE>` = 学习工作区；`<subject_path>` = `<LEARN_WORKSPACE>/.learning/subjects/<slug>`
- 本表**不重复**各角色的边界正文：边界仍写在各自规格里，只是可以改用代称
- **收录范围**：① 角色与协议规格正文里会提到的文件；② 学生或维护者要用的仓库入口（安装说明、工程约束、本表）。**不收纯开发工具**（发布、打包、预览脚本一类）

## 角色代称

角色（谁在干活）也有代称，正文里可以直接用。**派工给什么值由各角色规格的「输入」节定义**——值归消费者，它最清楚自己需要什么；本表只回答「谁维护哪份文件」，不再复述派工值。本表其余各节的「维护者」写的是技能名；**唯独两份记忆（共享记忆、科目记忆）写 `所有角色（直写）`**——它们是全角色收尾时直接追加的，没有单一维护者。

| 代称 | 技能名 | 一句话职责 |
| ---- | ------ | ---------- |
| 总控 | `learning-system` | 开场、盘问、调度、档案；唯一有用户通道的角色（学生只跟你说话） |
| 资料收集 | `resource-scout` | 收集权威教材与官方核对来源，产「资源清单」；把本地教材与可取到正文的来源转成 Markdown 入库 |
| 采图 | `image-scout` | 抓网页现成的位图，落「图片库」与「图片库索引」 |
| 课设 | `curriculum-designer` | 产「课程大纲」与实验课节点 |
| 讲解 | `learning-coach` | 写「课件内容文件」与「速查页」；配图规范的 owner |
| 出题评估 | `practice-evaluator` | 题目唯一 owner：出题、判分、**实验课验收**（结论写进「学习记录」；不写「评估记录」；阶段评估已删） |

## 一、工作区 · 共享与科目元数据

| 代称     | 文件名                | 功能                                                         | 相对路径                                | 维护者                                                  |
| -------- | --------------------- | ------------------------------------------------------------ | --------------------------------------- | --------------------------------------------------------- |
| 共享记忆 | `MEMORY.yaml`         | 记忆信息：画像三节（我是谁／教学偏好／学习习惯，答疑开张注入用）＋「积累」（跨科目的做法与事实，**不进任何注入**） | `<LEARN_WORKSPACE>/.learning/MEMORY.yaml` | 所有角色（直写）                                         |
| 科目记忆 | `MEMORY.yaml`         | 记忆信息：只有「积累」一节（只对**这门课**成立的做法与事实，一条 = 中文键 + 一句话，**不进任何注入**）。**新科目在建科目时**就从 `templates/subject-MEMORY.yaml` 预置这份带注释的空骨架（照抄，不用它当问卷填）；**旧科目**（这份骨架落地前建的）可能还没有，读侧按「不存在」处理——「按需存在」说的是这一层，不是「建科目时可以不建」 | `<subject_path>/MEMORY.yaml`            | 所有角色（直写）                                         |
| 科目使命 | `MISSION.md`          | 为什么学、学成什么样、约束与不学的范围                       | `<subject_path>/MISSION.md`             | `learning-system`                                         |
| 资源清单 | `RESOURCES.md`        | 延伸阅读与官方核对来源，每条一行用途并在行末标出服务哪几个节点（`· 服务 <节点 id>`，按节写） | `<subject_path>/RESOURCES.md`           | `resource-scout`（初次清单）／`learning-system`（小增量） |
| 术语表   | `GLOSSARY.md`         | `## 待掌握` 与 `## 已掌握`；正文与配图用词以此为准           | `<subject_path>/GLOSSARY.md`            | `learning-system`                                         |
| 科目档案 | `subject.yaml`        | 科目名、状态、目标、创建日期（过 `subject.schema.json`）     | `<subject_path>/subject.yaml`           | `learning-system`                                         |
| 课程大纲 | `curriculum.yaml`     | 节点 DAG、`kind`、`objective`（过 `curriculum.schema.json`） | `<subject_path>/curriculum.yaml`        | `curriculum-designer`（草稿）／`learning-system`（写盘）  |
| 学习进度 | `progress.yaml`       | 运行期状态三档（未开始／学习中／已学完，过 `progress.schema.json`） | `<subject_path>/progress.yaml`          | `learning-system`                                         |
| 误解库   | `misconceptions.yaml` | 误解条目（**唯一落点**；字段 topic／source／evidence／status／at，过 `misconceptions.schema.json`） | `<subject_path>/misconceptions.yaml`    | `learning-system`                                         |

## 二、工作区 · 课件与素材

| 代称         | 文件名                                                 | 功能                                                                           | 相对路径                                           | 维护者                                                                           |
| ------------ | ------------------------------------------------------ | ------------------------------------------------------------------------------ | -------------------------------------------------- | -------------------------------------------------------------------------------- |
| 课件内容文件 | `<序号>-<节点id>.md`                                   | 讲解、练习引入、配图、题目位置（`::: quiz` 锚点）；`kind: 实验` 的说明页也是它 | `<subject_path>/lessons/<序号>-<节点id>.md`        | `learning-coach`（实验说明页由 `practice-evaluator` 交、`learning-system` 搬入） |
| 练习题库     | `<序号>-<节点id>.quiz.json`                            | 键与内容文件的锚点逐字对应                                                     | `<subject_path>/lessons/<序号>-<节点id>.quiz.json` | `practice-evaluator`（落 `deliver/`）／`learning-system`（搬入）                 |
| 课件页面     | `<序号>-<节点id>.html`                                 | **已退役**：页面由阅读端实时渲染，不再预生成（要离线阅读走导出） | `<subject_path>/lessons/`                          | —（旧产物，只读）                                                                |
| 作答数据     | `<序号>-<节点id>.json`                                 | 作答历史、错因、上次结果；与课件一一对应（过 `attempts.schema.json`）；**绝不写回题库** | `<subject_path>/attempts/<序号>-<节点id>.json`     | 阅读端（学生作答时经 Host 半落盘）；`learning-system` **只读**                   |
| 速查页       | `reference/*.html`                                     | 手写 HTML 速查页（渲染器不吃它）                                               | `<subject_path>/reference/`                        | `learning-coach`                                                                 |
| 本地资料     | `reference/*.md`                                       | 转换后的本地教材／讲义，以及**学生自己在阅读端加的资料**（带来源标记）         | `<subject_path>/reference/`                        | `resource-scout`（转成）／**阅读端**（学生自加，ADR-0010）／`learning-system`（建科目时建目录） |
| 来源库       | `sources/*.md`                                         | 抓取／转换后的在线来源原文，供大纲与讲解对齐；**不挂科目主页**；按需建             | `<subject_path>/sources/`                          | `resource-scout`                                                                 |
| 科目组件     | `assets/` 下的 `style.css`／`quiz.js`／`lesson-toc.js` | **已退役**：渲染与判分都在阅读端，不再往每个科目拷副本                       | `<subject_path>/assets/`                           | —（旧产物，只读）                                                              |
| 图片库       | `assets/img/pool/` 下的图                              | 采集来的图与自产的图，同一处存放                                               | `<subject_path>/assets/img/pool/`                  | `image-scout`（采集）／`learning-coach`（自产）                                  |
| 图片库索引   | `pool.md`                                              | 七列表头 + 每张一行 + 末尾 `## Gaps`；课件按它检索                             | `<subject_path>/assets/img/pool.md`                | `image-scout`（采集行）／`learning-coach`（自产行，只追加自己那行）              |
| 产图脚本     | `assets/img/gen/<同名>.py`                             | 自产图的可复现脚本                                                             | `<subject_path>/assets/img/gen/`                   | `learning-coach`                                                                 |
| 实操任务     | `lab/NNNN-主题/`                                       | 留白任务与断言（学生动手的地方）                                               | `<subject_path>/lab/`                              | `practice-evaluator`（落 `deliver/`）／`learning-system`（搬入）                 |
| 实操答案     | `lab/solutions/NNNN-主题/`                             | 参考解，与任务分开放                                                           | `<subject_path>/lab/solutions/`                    | `practice-evaluator`                                                             |
| lab 说明     | `lab/README.md`                                        | 载体与环境依赖、任务表、卡壳顺序                                               | `<subject_path>/lab/README.md`                     | `learning-system`                                                                |
| lab 运行入口 | `干净态.sh`／`作答态.sh`／`自检.sh`                    | 两个跑法各一个入口（干净态＝任务留白、作答态＝把参考解摆进临时副本），`自检.sh` 按顺序各跑一遍；三者都只摆盘 + 调 `check.sh` + 原样转述事实（判分入口仍只有 `check.sh` 一个） | `<subject_path>/lab/`                              | `practice-evaluator`（照 `templates/lab/` 骨架交）／`learning-system`（搬入）    |

## 三、工作区 · 档案与生成产物

| 代称     | 文件名                   | 功能                                                           | 相对路径                           | 维护者                                                  |
| -------- | ------------------------ | -------------------------------------------------------------- | ---------------------------------- | ------------------------------------------------------- |
| 评估记录 | `NNNN-<节点id>.md`       | **已退役**：不再产生新文件，旧文件保留可读（结论写进「学习记录」） | `<subject_path>/assessments/`      | —（旧产物，只读）                                       |
| 学习记录 | `NNNN-dash-case.md`      | 有可观察证据才写一条                                           | `<subject_path>/learning-records/` | `learning-system`                                       |
| 会话摘要 | `YYYY-MM-DD.md`          | **已退役**：不再产生新文件，旧文件保留可读（开场不再读会话记录） | `<subject_path>/sessions/`         | —（旧产物，只读）                                       |
| 科目主页 | `index.html`（科目级）   | **已退役**：阅读端实时渲染；离线要一份走导出（#82）            | `<subject_path>/index.html`        | —（旧产物，只读）                                       |
| 根主页   | `index.html`（工作区级） | **已退役**：同上                                               | `<LEARN_WORKSPACE>/index.html`     | —（旧产物，只读）                                       |

