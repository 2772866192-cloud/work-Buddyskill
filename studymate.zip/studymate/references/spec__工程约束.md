# StudyMate 工程约束

> **定位**：引擎项目的**工程硬约束**——目录与资源约定、规则归属、工具指针，以及"哪条规则归哪个
> skill 管"的指路。系统形状见 [目标态规格](../设计/目标态规格.md)，日常使用见
> [使用说明](../使用/使用说明.md)，工作区数据骨架见 [templates/README.md](../../templates/README.md)。
>
> 本文档的前身是《实施计划》：那份按任务拆的构建台账（Task 1–14、"已交付"清单、依赖 DAG）
> 已随 v0.1 交付删除，**约束部分留在这里**；改引擎只读本文档与上面那几份。
>
> **#83 拆除之后这里少了三节**：模板占位符契约、脚本一览、前端技术选型。页面不再预生成，
> Python 引擎退役，模板与前端资源全部删除——那一节的形状改由**阅读端与导出域**定义
> （[目标态规格](../设计/目标态规格.md) §4、§8；代码是 [`lib/export/`](../../lib/export/)）。

## 一、三个区域，互不混用

| 区域 | 位置 | 是什么 |
|---|---|---|
| **引擎项目** | `<root>/`（本仓库） | 系统源码：skills 源、preset 源、schemas、工作区数据骨架（`templates/`）、`lib/` 引擎、`bin/`、docs。学习时只读 |
| **用户级安装** | `~/.dsh/`（DSH）／客户端插件目录（Codex、ChatGPT Work） | 学习模式预设与 `studymate-config.yaml`（工作区定位），standalone 安装另有一份只读材料副本。由 `npx` 安装器或插件 ZIP 管理，与会话目录无关 |
| **学习工作区** | 首次安装默认 `~/StudyMate/`，已有配置会沿用 | 所有学习数据：`.learning/` 与导出的 `export/`。布局见 [使用说明 §六](../使用/使用说明.md#六学习数据存在哪) |

- **会话可在任意目录启动**：总控开场先读 `~/.dsh/studymate-config.yaml` 拿 `workspace`（记为 `LEARN_WORKSPACE`）与 `root`；读写一律基于这两个路径，**不在会话 cwd 里建或找学习文件**。
- **学习数据直接写进配置里的学习工作区**：写盘由插件 Host 半完成，agent 沙箱的可写集不再是前提——**暂存模式已删**（[ADR-0008](../adr/0008-删掉暂存模式.md)）：没有"开场先建 `<SESSION_DIR>/.studymate-stage/<slug>`、收尾问一次落点、再 `cp -a` 搬过去"这套机制，也没有落点偏好文件。技能侧的开场只剩一次工作区摘要工具调用（DSH），无头宿主按各自宿主约定选定工作区。**产物交接用的科目内 `.stage/` 保留**——它服务的是产物门禁，不是权限。**规则全文在 `record-keeping` 的「落点与边界」**。
- **预设源有两份**：`<root>/preset/learning/`（「学习模式」）与 `<root>/preset/qa/`（「答疑模式」，#104）。两条预设由**原生安装**在同一次调用里注册上（共用一段托管块）；`npx -y @yunmiao/studymate@latest install` 的声明式那条**只声明「学习模式」**——答疑模式的取课件工具行（`@yunmiao/studymate/qa-preset`）要包在档位里才解析得到，而声明式安装不把包放进档位（#204）。**禁止直接改 `~/.dsh/` 下那份**。注册的判定与补丁拼接在 [`lib/preset.ts`](../../lib/preset.ts)（原 Python 安装助手的 TS 替代，返回值形状逐字段一致），两条预设的 id / order 与插件行在各自目录的 `preset.yml` / `agent.cordis.yml`。
- **Codex / ChatGPT Work 插件从同一份源构建**：`npm run build:plugin` 把 `preset/skills`、`schemas`、`templates`（数据骨架）与 `openai/studymate/` 合成 `dist/studymate/` 与 `dist/studymate-openai.zip`（`dist/` 不入库）。Antigravity 侧同理由 `npm run build:antigravity` 构建。改这些源会同时影响两侧；**插件清单（`plugin.json`）里的 `version` 由构建器从 `package.json` 注入**，源文件不写版本（写了也不会进产物）。ZIP 由 [`bin/zip.mjs`](../../bin/zip.mjs) 打：零依赖、确定性（固定时间戳与条目顺序，重建逐字节相同）
- 面向学生的输出一律中文；skill 内部指令用中文。

## 二、目录与规则归属

```text
<root>/
├── AGENTS.md                  # agent 入口：只放指针，指向下面各份的唯一出处
├── CONTRIBUTING.md            # 贡献规矩的唯一出处（改哪块先读哪份、门禁、PR 流程、提交信息）
├── GLOSSARY.md                # 领域词表
├── bin/studymate.mjs          # npx 安装 + 两个宿主的插件构建 + export 子命令
├── bin/dsh-plugin.ts          # DSH 插件入口（Host 半）：预设、原生工具、阅读端数据路由
├── lib/                       # 引擎（Node 原生跑 TypeScript，无构建步骤）
│   ├── core/                  #   纯函数域：内容格式、锚点、题目、规则、schema 子集校验
│   ├── host/                  #   数据域词表、越权 guard、域数据读法（工具域与实验域共用）
│   ├── tools/  tasks/  watch/  ask/  lab/  export/   #   工具、任务、监听、问答、实验、导出各域
│   ├── katex/                 #   随包发的 KaTeX dist（第三方：代码与 CSS 是 MIT、fonts/ 是 SIL OFL 1.1，两份许可证都随副本发）：公式排版资源，不是我们的源码
│   ├── client.js              #   Client 半：阅读端本体（手写 JS，零构建，见 ADR-0002）
│   └── *.ts                   #   Host 数据层：workspace / library / reference / assets / yaml / preset …
├── preset/learning/           # 预设源之一：「学习模式」（agent.cordis.yml 里的 skill 目录由安装器写入）
├── preset/qa/                 # 预设源之二：「答疑模式」（#104）：四行插件，工具面由 lib/tools/qa-preset.ts 收窄
├── preset/skills/             # 技能源（唯一源）：平级一层，DSH 只扫一层找 SKILL.md。
│   │                          # **位置是刻意的**——宿主默认会扫「项目根/.dsh/skills」，
│   │                          # 技能摆在那里，任何工作目录落在本仓库里的会话都看得见它们（#87）
│   ├── learning-system/       # 总控（唯一被模型加载的入口）
│   ├── resource-scout/  image-scout/  curriculum-designer/     # 角色：两个调用面都关
│   ├── learning-coach/  practice-evaluator/                    # 角色：两个调用面都关
│   └── learning-discovery/ lesson-design/ layered-practice/ evidence-check/ local-qa/ record-keeping/   # 协议：可被 skill 工具加载
├── schemas/                   # 数据结构（curriculum / progress / subject / question / misconceptions / attempts / agent-handoff 等）
├── templates/                 # **工作区数据骨架**：新建科目与共享记忆时写进工作区的文件模板；`lab/` 那一份是造 lab（#197）时照抄的实验骨架
├── openai/studymate/          # OpenAI 插件源：plugin.json / 交互断点脚本 / 参考文档
├── antigravity/studymate/     # Antigravity 插件模板与清单（plugin.json / rules/AGENTS.md）
├── scripts/                   # 门禁与发布：tests/（套件）、release/（打包、校验、类型检查）
├── docs/                      # 文档，按用途分类
│   ├── 使用/                  #   安装 / 使用说明 / Antigravity / Codex 与 ChatGPT / 发布
│   ├── 设计/                  #   目标态规格 / 实施路线 / 重构评估（历史）/ 方向探索指南与验收
│   ├── 规范/                  #   工程约束（本文）/ 课件内容格式 / 阅读端呈现 / 文件归属 / Agent 交接协议
│   ├── adr/                   #   架构决策记录，按需创建（有决策才建）
│   ├── agents/                #   agent 约定层：issue tracker / triage 标签 / 领域文档布局 / 编排纪律
│   └── images/                #   README 用的截图
├── dist/                      # build:plugin / build:antigravity 的产物（插件目录 + ZIP，已 gitignore）
└── workspace/                 # 可选本地学习工作区（已 gitignore）
```

**`lib/` 下的一级目录就是「域」**（`core` / `host` / `tools` / `tasks` / `watch` / `ask` / `lab` / `export` / `katex`——最后一个是随包发的第三方 dist，登记进表是为了不给「新增目录一律要登记」开例外），直接躺在 `lib/` 里的文件属于域 `lib`；允许谁 import 谁由 [`test_architecture_boundaries.mjs`](../../scripts/tests/test_architecture_boundaries.mjs) 顶部那张**域规则表**唯一规定——新增一个一级目录不在表里登记，门禁就红。

**为什么没有示例工作区、页面模板与 Python 引擎脚本**：示例与生成产物不再入库
（[ADR-0009](../adr/0009-示例与生成产物不再入库.md)），页面模板与前端资源随静态渲染一起退役
（[ADR-0005](../adr/0005-静态页面降为导出.md)），Python 引擎迁成了 `lib/**` 的 TypeScript
（[ADR-0002](../adr/0002-引擎改用TypeScript.md)）。测试要用的科目**现造现弃**。

**规则归属（一处定义，别处只给指针）**：

- **文件代称与归属**的唯一出处是 [`docs/规范/文件归属.md`](文件归属.md)（代称 ↔ 路径 ↔ 维护者）：角色规格正文用「代称」指代文件，凡是要照着执行的（命令、路径模板、`cp`）仍写全路径
- **阅读端呈现**（四个面「看起来对不对」的意图判据、问答引用的保持行为）的唯一出处是
  [`docs/规范/阅读端呈现.md`](阅读端呈现.md)——**维护者：仓库维护者**（单维护者项目，`docs/**` 的归属随仓库走），
  随它一起改的是 `lib/client.js` 的呈现面与 `scripts/tests/browser/reading_routes_test.mjs` 那批套件。
  三栏让位顺序仍归 [ADR-0011](../adr/0011-阅读端三栏让位顺序.md)，公式与配图的内容侧写法仍归
  [课件内容格式](课件内容格式.md)——**本文不复述那份规范的内容**（与这里每条同一条规矩）
- **可选方向探索**归 `learning-discovery`，由总控按需加载并亲自执行；问数、会话状态与建课交接见 [协议](../../preset/skills/learning-discovery/SKILL.md)，不新增角色、数据 schema 或持久化探索档案
- **课件**的唯一约束来源是 `lesson-design`（要素／实操规范／讲法倾向／记忆难度／贯穿线索／复用骨架）
- **题目**的唯一规范是 `layered-practice`，出题与评估归 `practice-evaluator`
- **staged 子 agent 交接**的唯一工程协议是 [`Agent交接协议.md`](Agent交接协议.md)；它只验证交接边界，不替代领域校验
- 完成证据核验 `evidence-check`、局部答疑 `local-qa`、学习状态读写 `record-keeping`
- 本文档只写**路径与工程硬约束**，不重复上面那些内容

**角色规格的判据（长期，#194 落定）**：一条角色步骤如果需要**读渲染端源码反推约定**（目录叫什么、页面吃什么、字段怎么拼），那就是**规格 bug**——那个约定的唯一出处没写下来，或者指针不到位；补进规范，别让角色去考古。反过来，读 `schemas/**` 与 `lib/core/**` 的核心纯函数实现（指令白名单、题库字段、锚点规则）是**规范指定的工序**，不算缺口；规范只写它们的地址与用法要点，**不抄内容**——抄一遍就是第二个真相。

**分工原则**：角色 skill 只定义"职责 + 做法 + 输入输出格式"，不碰别的角色的文件；总控是唯一被模型直接加载的入口，且**信息源在它上下文里的活（答疑、盘问、四份元数据、全部档案记录）它自己干**；只有需要外部检索／大量生成／独立验证的活才派角色。

**落点偏好落哪一层**：**已随暂存模式删除**（[ADR-0008](../adr/0008-删掉暂存模式.md)）——学习数据直接写配置里的 `workspace`，没有"收尾问落点、记住上次落点"这两步，也就没有会话侧偏好文件这一层。

**等待语义归框架，不归提示词**：子 agent 是后台派出的（continuable 模式返回 `subagentId`，**不是** `jobId`），它那一轮结束会**自动给父会话送通知**并唤醒空闲的父线程——这套机制由 DSH 的系统提示与工具描述保证，技能里**不复述**，也不写 `job_output(wait: true)`（那个 API 只对有 `jobId` 的后台作业有效，对子 agent 无效）。技能只写框架管不到的那半：**同一科目同时只有一个写入者**，上一支没回来别派下一支（规则在 `learning-system` 的「交接与返回」）。

**技能调用面**（`preset/skills/*/SKILL.md` 的 frontmatter，由 `scripts/tests/test_skill_frontmatter.mjs` 校验）：

- 总控与 6 个协议允许模型按名字加载（`skill` 工具）；**5 个角色两个面都关**（`disable-model-invocation: true` + `user-invocable: false`），只作为磁盘上的规格文件，由总控在派发 prompt 里给出绝对路径，角色自行读取
- 预设用 `customSkillDirs` 指向技能源并设 `includeDefaultRoots: false`：学习会话只加载本项目技能，也不往 `~/.dsh/skills/` 装链接

**技能与工具的可见边界**（#87 落定，`scripts/tests/test_skill_visibility.mjs` 守）：

- **技能源住在 `preset/skills/`**，那是学习预设自己的目录。预设用 `customSkillDirs` 指向它（占位符由安装器换成绝对路径）并设 `includeDefaultRoots: false`：入方向——学习会话只加载 StudyMate 自己的 12 个技能，不背机器上别人装的技能。
- **别把技能挪回 `<项目根>/.dsh/skills`**（也别挪去 `.agents/skills`）。宿主的 `skill-filesystem` 默认 `includeDefaultRoots: true`，会按「从工作目录向上第一个含 `.git` 的祖先」找项目根，再扫这两个位置——技能摆在那里，**任何**工作目录落在本仓库/本包里的会话（别的预设、别的任务）都会吃到它们，边界就退化成「会话恰好不在本仓库里」这种巧合。出方向由上面那条套件守：它照宿主规则走一遍当前 cwd，断言那两条路径上什么都没有。
- **工具收进了预设，面板与 slot 仍在包级**（#138 收口，#84 用户故事 36 的**工具面**那一半）：九个 `studymate_*`、五个 `studymate_task_*` 与一个 `studymate_lab_run` 由「学习模式」预设自己那条插件行在**预设作用域**里注册（`preset/learning/agent.cordis.yml` 的 `studymate-tools → @yunmiao/studymate/learning-preset`，实现在 [`lib/tools/learning-preset.ts`](../../lib/tools/learning-preset.ts)），所以同一个 profile 里别的预设（含宿主内置的 standard）的会话**看不见它们**；profile 根上只留**宿主层**——导出的任务类型、任务域那条阅读端路由与销毁回执、实验域的任务类型与台账、文件监听（`bin/dsh-plugin.ts` 调 [`registerStudyMateHost`](../../lib/tools/index.ts)）。**客户端面板与 slot 仍是包级**（`package.json` 的 `dsh.client`）：宿主没有「按预设注册面板」的接口，加载了这个包的 profile 每个会话都会挂上它——那一半偏离留着，哪天宿主给了接口再收。沿革：#104 的答疑预设曾用 `ctx.tools.restrict({ deny })` 抹掉 profile 根上那 15 个名字；工具搬进预设之后那份名单拆了（[`lib/tools/qa-preset.ts`](../../lib/tools/qa-preset.ts) 只剩只读工具那一条）。判据仍是「这条会话看得见哪些工具」：[`test_skill_visibility.mjs`](../../scripts/tests/test_skill_visibility.mjs) 钉注册面（预设载荷里有那条工具面行、profile 根 ctx 上一个都不注册），[`test_dsh_runtime.mjs`](../../scripts/tests/test_dsh_runtime.mjs) 在**真 DSH** 里从预设作用域 dispatch 并反证 profile 根上没有。

## 三、原生工具（退役的「脚本一览」指到哪去）

**引擎没有脚本了**：Python 引擎随 #83 退役，技能与总控调用的是**原生工具**。工具的名称、参数、
返回形状与域边界的**唯一出处是代码**：

| 你要什么 | 去哪看 |
|---|---|
| **学习面**有哪几个工具、注册顺序、名字表 | [`lib/tools/index.ts`](../../lib/tools/index.ts) 的注册点与 `STUDY_TOOL_NAMES`（九条） |
| **答疑面**有哪几个工具、名字表 | 同一个文件的 `QA_TOOL_NAMES`（一条只读的 `studymate_lesson_read`）——它**不在**学习面的九条里，由答疑预设那条插件行 [`lib/tools/qa-preset.ts`](../../lib/tools/qa-preset.ts) 注册进预设自己的作用域，所以学习会话的工具面上没有它 |
| 参数表、返回形状、错误形状、域边界（给人读的） | [`preset/skills/learning-system/references/tools.md`](../../preset/skills/learning-system/references/tools.md)——**按需读，别背进上下文**；答疑面那条只读工具的参数表与返回形状也在那一份里，并注明它不在学习会话的工具面上 |
| 无头宿主（Antigravity / Codex）怎么办 | 那边没有原生工具，也没有引擎脚本：技能导出时把工具名换成「按 schema 与格式要求逐项自查」，导出走 `npx -y @yunmiao/studymate export`。映射表在两个适配器的 `NATIVE_TOOL_FALLBACK` |
| 导出：产物形状、泄漏守卫、任务模型 | [`lib/export/`](../../lib/export/)；无头侧入口是 [`lib/export/cli.ts`](../../lib/export/cli.ts) |

**本文档不再抄第二份参数表**：抄一份就多一处会漂的副本，而漂了的后果是模型照着一份过时契约调用。
工具说明（写进模型 API 的 `description`）只有一句话，参数表由技能按需加载——这条纪律在
[`lib/tools/define.ts`](../../lib/tools/define.ts) 里焊着（`DESCRIPTION_LIMIT`）。

### 宿主契约：形状照哪几份源码，怎么验

我们递给宿主的东西（工具的 schema、预设的插件行、程序化建会话的调用、阅读端那几个客户端服务调用）
形状**由宿主的源码定**，我们这边没有类型可依（Host 半刻意零依赖，见
[`bin/dsh-plugin.ts`](../../bin/dsh-plugin.ts) 的文件头）。2026-10-07 连着出过两次事故：
`studymate_lesson_read` 的输出契约有 `const` 没 `type`（宿主当场拒收，预设行整行挂不上）、
`agents.create` 漏了 `agentOptions`（会话建得出来，一按发送才报没有模型）。两次都是**递过去的形状**
不合规或不完整，而当时的门禁里没有一条判据问得到宿主。

**定位宿主源码**：`STUDYMATE_DSH_PACKAGE` 指向已安装的 DSH 包目录（与 `npm run test:dsh` 同一个
环境变量）。包内各模块在 `<包目录>/node_modules/@deepseek-ai/<模块>/lib/**`。下表的路径按
`0.2.0-rc.2` 核对过；宿主升级后先跑 `npm run test:dsh-contract`，它会把漂的地方指出来。

| 你要改的形状 | 读哪一份（唯一判据） |
|---|---|
| 工具的 schema（`parameters` / `output.schema`） | `dsh-tools/lib/types/json-schema.js` 的 `checkSchemaNode`（`assertSupportedJsonSchema` 就是它）。不只关键字清单，还有**放置规则**：`const`/`enum` 要配 `type` 或 `oneOf`，`type` 与 `oneOf` 不能并列，本体关键字不能挂错 type |
| 按预设程序化建会话（`agents.create` 的字段） | `dsh-webhook/lib/types/session.js` 的 `createWebhookSession`——宿主唯一一份完整范例，照它抄时**逐字段对**；字段类型在 `dsh-agent/lib/types/index.d.ts` |
| 预设注册与挂载（`PresetDefinition`、realm/isolate、预设作用域里的 `restrict`） | `dsh-agent-preset-registry/lib/index.js`（`register`/`mount`）、`dsh-agent-preset/lib/index.js`（配置校验）、`dsh-tools/lib/index.js` 的 `view()` 与 `restrict()` |
| 引用进草稿（`insertReference` 的坐标空间、草稿的两套投影） | `dsh-client-ui-conversation/lib/client.js`（`compose()`、`insertReference`、`detectOffsetOfClipboardOffset`） |
| 注册引用来源与 codec | `dsh-client-ui-input-trigger/lib/types/types.d.ts`、`dsh-client-ui-input-trigger/lib/types/client/service.d.ts` |
| 嵌会话正文、拿 `SessionProvider` | `dsh-client-ui-renderer/lib/client.js`（`standardKit` / `factoryKit` 的判据）、`dsh-client-ui-subagent/lib/client.js`（官方用法） |

两条纪律：**照参考实现抄调用块时逐字段对**（少一个字段、多一个字段都是漂）；形状的判据优先
**问宿主本人**——`npm run test:dsh-contract` 直接拿宿主的校验器扫我们注册点上全部工具的 schema，
并对参考调用的字段清单做漂移检查。仓库里那份手抄的子集检查
（[`scripts/tests/test_tools_schema_subset.mjs`](../../scripts/tests/test_tools_schema_subset.mjs)）
留在默认门禁里当 CI 那一层，它的文件头记着这次手抄漂掉的事故。

### 阅读端 HTTP 路由：注册约定与错误信封

阅读端（`lib/client.js`）与 Host 半之间走 `/api/studymate/*` 下的**精确路由**（`library` /
`asset` / `reference` / `attempts` / `qa/session` / `lab-run` / `tasks` / `events` /
`math`——`math` 是公式资源，一条文件一条路由、清单在 `lib/math.ts`；`qa/session` 是 #105 起
「建一条答疑会话」那条，会话按「答疑模式」预设由宿主半建，客户端建不出来（`sessions.create`
丢 `agentPreset`）；面板自己调模型那条 `ask` 已由 #107 退役）。注册在 `/api` 之下
**自动**获得宿主那层的 Host/Origin 检查与浏览器会话认证（`dsh-plugin-api.md` §6.3），不用自己写鉴权。
两条约定，改路由之前先看：

**一、注册约定只有一种：收外层 ctx、自己 `inject(['connection'])`。**
`registerAskSessionRoute(ctx)` / `registerTaskRoute(ctx, service)` / `registerAttemptRoutes(ctx)` /
`registerLabRoute(ctx)` / `registerMathRoute(ctx)` 都是这个形状——「`connection` 就绪才注册、缺了就不挂」由路由自己的模块回答，
`bin/dsh-plugin.ts` 只留一行注册（它那边一律动态 `import`，见文件里的加载边界说明）。注册是有主的
副作用，走 `connectionCtx.effect`，卸载时各自拆各自的。`registerWatchChannel` 是推送通道（SSE）而不是
请求-应答路由，它要的是注入后的那层 ctx。

**二、失败恒为一份信封：`{ ok: false, error: { code, message }, ...extra }`。**
唯一构造点是 [`lib/route-envelope.ts`](../../lib/route-envelope.ts)（`errorBody` / `routeError`），
数据层的回执（`AttemptsRefusal` / `ReferenceRefusal` / `MisconceptionRefusal`）也用它——回执被路由
**原样**递出去，两处各拼一遍就是两套信封。

- `code`：机读短码，客户端按它分支。**词表只有一份**（同文件里的 `ROUTE_ERROR_CODES`），
  新增一个码要加进词表——`scripts/tests/test_host_route_envelope.mjs` 扫源码，用了表外的码就红。
- `message`：给人看的**一句话**，原样显示在界面上（学生照着它能自救），不许是空串。
- `extra`：这一条路由额外要带回去的字段（冲突时的 `attempts` / `version`、面板的 `available` /
  `model`）。`ok` 与 `error` 不许被 extra 覆盖（构造点里排在后面）。
- 成功那一侧**不统一**：`{ok:true, attempts, version}`、`{at, tasks}`、答疑会话那条的
  `{available, ok, sessionId, title…}` 本来就在说不同的事，硬凑成一个形状只会多一层没用的壳。

客户端那侧读它的只有两个函数（`lib/client.js` 的 `routeCode` / `routeMessage`）；它是手写 JS、
不进 `tsc`，所以「只从 `error.code` / `error.message` 取值」由上面那条套件钉着。

**三条路由有意不走这个信封**，别照着它们「统一」回去：`asset` 是图片地址（`<img src>` 直接吃
响应体，回 JSON 没有意义，失败就是 404/500 的纯文本），`events` 是 SSE 流（响应体是一串事件，
不是一份 JSON），`math` 是随包发的公式排版资源（`lib/math-route.ts` 投的是文件字节，失败就是
一句纯文本 404——阅读端据此降级成可读的 TeX 原文）。

## 四、门禁三层与测试入口

| 层 | 查什么 | 谁在跑 |
|---|---|---|
| **数据层** | `schemas/*.json` 校验、引用完整性、大纲 DAG 无环与位次不倒挂、实验课前置非空 | `studymate_validate_curriculum` 工具；`scripts/tests/test_validators_*.mjs` |
| **内容层** | 内容格式解析、锚点与题库逐字对账、图片存在性、公式标记 | `studymate_validate_lesson` / `_pool` / `_handoff`；`scripts/tests/test_core_*.mjs`、`test_tools_*.mjs` |
| **渲染冒烟** | 拿一份**现造**的临时工作区真渲染一遍：阅读端本体（真浏览器）与导出的产物（file:// 真渲染、含公式与图片） | `scripts/tests/browser/reading_test.mjs`、`browser/export_file_test.mjs` |

测试与门禁的入口、各命令的前置与按需项见 [测试说明](../../scripts/tests/README.md)；日常使用视角
（什么时候跑、哪些是阻断项）见 [使用说明 §五](../使用/使用说明.md#五质量检查)。
**测试数据一律现造现弃**，仓库里不存示例工作区。

## 五、几条实测过的坑

- **YAML 里的日期一律加引号**：`created_at: "2026-09-15"`。不加引号会解析成日期对象，schema 要求字符串，校验失败
- **YAML 值里出现 `": "` 必须加引号**（例如 `Cache-Control: no-store`），否则解析报 mapping values are not allowed here
- **值以 YAML 指示符开头（`*` `&` `!` `|` `>`）必须加引号**：两份记忆里最常写的那一种就是 `"**加粗**"`。裸写会被 [`lib/yaml.ts`](../../lib/yaml.ts) 当成别名／标签拒掉（报「不支持别名 `*`」），那份记忆在阅读端当场打不开——写法写在 `templates/` 两份记忆骨架的注释与 `record-keeping` 的「共享记忆」节里
- **写给工作区的路径一律钉成绝对路径**（配置是机器全局的，留相对路径换个目录开会话就找不到工作区）
- **`curriculum.yaml` / `progress.yaml` / `subject.yaml` / 误解库 / 作答数据按 `schemas/*.json` 校验后才算交付**：校验走 `studymate_validate_curriculum`（写侧三份数据）与 `studymate_validate_lesson`（内容与题库），返回的是逐条问题（文件 + 行号 + 是否阻断），不是退出码
- **技能 frontmatter 只能有一层 YAML 映射**：直接当成完整 YAML 文档解析会因多文档报错；解析器在 [`lib/yaml.ts`](../../lib/yaml.ts)，技能那一侧由 `scripts/tests/test_skill_frontmatter.mjs` 守
- **`lib/yaml.ts` 默认只认学习文件需要的那一小撮 YAML**：标签、块标量、多行 plain 标量、成对文档标记**见到就报错**——学习文件里没有这些构造，解析错的后果比报错难查。两份 cordis 配置（profile 补丁与预设插件列表）要用到时**显式开**（`tags` / `blockScalars` / `plainScalarContinuation` / `documentMarkers`，含组合，例如设置页写的 `!!js >-`），默认没变。每个选项的语义只写在 [`lib/yaml.ts`](../../lib/yaml.ts) 的文件头，这里不复述
